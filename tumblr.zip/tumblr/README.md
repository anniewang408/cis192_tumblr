# Overview
This project is a personal blog! There is a splash page with the route "/", a blog page that sorts all the posts by most recent, and each post has its own page. 

## Admin Login Info
To login to localhost:8000/admin, here is the admin info:
    username: anniewang
    email: anniwang@seas.upenn.edu
    password: password 

## To run the project:
To run the project, run python manage.py runserver from the top level folder! Then, navigate through the pages. I included a fun blog post about making my favorite rosemary focaccia. Feel free to add posts too :). I hope you enjoy!

## Attributions:
I used an online CSS template from https://www.w3schools.com/w3css/w3css_templates.asp